Code barre 128 et EAN 13------------------------
Url     : http://codes-sources.commentcamarche.net/source/102909-code-barre-128-et-ean-13Auteur  : VallorbainDate    : 17/01/2019
Licence :
=========

Ce document intitul� � Code barre 128 et EAN 13 � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Permet d'utiliser une police de code barre 128 ou EAN 13.
<br />Contient les fo
nctions d'encodage pour les polices.
<br />A été testé avec une douchette : 
fonctionne parfaitement...
